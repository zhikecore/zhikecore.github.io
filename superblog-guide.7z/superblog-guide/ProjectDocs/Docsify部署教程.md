## 参考文章

- [Docsify部署IIS](https://www.cnblogs.com/Can-daydayup/p/15779788.html)
- [GitHub Pages](https://docsify.js.org/#/zh-cn/deploy?id=github-pages)
- [GitLab Pages](https://docsify.js.org/#/zh-cn/deploy?id=gitlab-pages)
- [Gitee Pages](https://docsify.js.org/#/zh-cn/deploy?id=gitee-pages)
- [Docker](https://docsify.js.org/#/zh-cn/deploy?id=docker)
- [Firebase 主机](https://docsify.js.org/#/zh-cn/deploy?id=firebase-主机)
- [VPS](https://docsify.js.org/#/zh-cn/deploy?id=vps)
- [Netlify](https://docsify.js.org/#/zh-cn/deploy?id=netlify)
- [ZEIT Now](https://docsify.js.org/#/zh-cn/deploy?id=zeit-now)
- [AWS Amplify](https://docsify.js.org/#/zh-cn/deploy?id=aws-amplify)
- [官方docsify部署教程](https://docsify.js.org/#/zh-cn/deploy)
- [30分钟使用Docsify+Github Pages搭建个人博客 ](https://www.cnblogs.com/Can-daydayup/p/15779888.html)

